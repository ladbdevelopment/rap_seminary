# Seminario-COL-Medellin
Seminario Colombia - Medellin
