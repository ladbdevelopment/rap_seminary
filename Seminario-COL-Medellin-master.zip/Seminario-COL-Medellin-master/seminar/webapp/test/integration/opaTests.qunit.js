/* global QUnit */

sap.ui.require(["seminar/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
