sap.ui.define([
	"seminar/test/unit/controller/Launchpad.controller"
], function () {
	"use strict";
});
